<?php include('../header.php');?>

        <!-- Page Banner Start -->
        <div class="section page-banner-area bg-cover" style="background-image: url(../assets/images/banner-img.jpg);">
            <div class="container">
                <!-- Page Banner Wrapper Start -->
                <div class="page-banner-wrapper">
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- Page Banner Content Start -->
                            <div class="page-banner text-center">
                                <h2 class="title">Privacy Policy</h2>
                                <ul class="breadcrumb justify-content-center">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Privacy Policy</li>
                                </ul>  
                            </div>
                            <!-- Page Banner Content End -->
                        </div>
                    </div>
                </div>
                <!-- Page Banner Wrapper End -->
            </div>
        </div>
        <!-- Page Banner End -->




<?php include('../footer.php');?>